(function(window, undefined) {
  var dictionary = {
    "bda86572-c923-42e7-8333-b56c3a9c39da": "Lightning Control",
    "dc7c0af5-d918-4cd2-a85c-63dd33111c91": "Home Security 1",
    "16e1d02e-3e07-4d5e-bce1-8b706fa96727": "Appliance Manager",
    "2054d39e-2f83-45bb-95fe-e478313758c0": "Temperature Settings",
    "78d947d0-e83f-4f8d-bebc-50b84c73a38a": "Home Security",
    "a9f42a06-ad2b-4292-88a3-c86043c36352": "Alarm Clock",
    "ac849cdb-956e-4a83-9e45-b234310df425": "Home Screen 1",
    "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4": "Accessibility Settings",
    "0004e177-187f-48bf-af37-939b7a6cdbc5": "Voice Command",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Home Screen",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "Board 1"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);