(function(window, undefined) {

  var jimLinks = {
    "ac849cdb-956e-4a83-9e45-b234310df425" : {
    },
    "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4" : {
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
    }    
  }

  window.jimLinks = jimLinks;
})(window);