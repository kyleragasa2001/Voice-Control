var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1730547994919.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-16e1d02e-3e07-4d5e-bce1-8b706fa96727" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Appliance Manager"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/16e1d02e-3e07-4d5e-bce1-8b706fa96727/style-1730547994919.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/16e1d02e-3e07-4d5e-bce1-8b706fa96727/fonts-1730547994919.css" />\
      <div class="freeLayout">\
      <div id="s-Path_1" class="path firer commentable pin vpin-end hpin-center non-processed-pin non-processed" customid="Home indicator"   datasizewidth="135.00px" datasizeheight="5.00px" dataX="-0.00" dataY="27.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="135.0" height="5.0" viewBox="147.49999999999994 900.0 135.0 5.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-16e1d" d="M149.99999999999994 900.0 L279.99999999999994 900.0 C281.3714594258871 900.0 282.49999999999994 901.1285405741129 282.49999999999994 902.5 L282.49999999999994 902.5 C282.49999999999994 903.8714594258871 281.3714594258871 905.0 279.99999999999994 905.0 L149.99999999999994 905.0 C148.62854057411278 905.0 147.49999999999994 903.8714594258871 147.49999999999994 902.5 L147.49999999999994 902.5 C147.49999999999994 901.1285405741129 148.62854057411278 900.0 149.99999999999994 900.0 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-16e1d" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer commentable non-processed" customid="Battery full"   datasizewidth="32.42px" datasizeheight="19.30px" dataX="368.00" dataY="25.12"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="32.419960021972656" height="19.295860290527344" viewBox="368.0 25.122129440307575 32.419960021972656 19.295860290527344" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-16e1d" d="M373.9209969180518 44.41799020767208 L390.83200690123846 44.41799020767208 C392.79487750144597 44.41799020767208 394.33709769821644 44.14226288573474 395.44799242789696 42.721577844486596 C396.54809038743264 41.300892803238455 396.753016033824 39.35622168705351 396.753016033824 36.845815384071074 L396.753016033824 32.69424065847217 C396.753016033824 30.170182383938503 396.54809038743264 28.22547834258647 395.44799242789696 26.818633844301033 C394.3263009280716 25.397980979920728 392.79487750144597 25.122129440307575 390.83200690123846 25.122129440307575 L373.88865049216963 25.122129440307575 C371.9581140301696 25.122129440307575 370.41585638524776 25.397980979920728 369.3157726150507 26.818633844301033 C368.2049160649308 28.239272490995557 368.0 30.18399299493113 368.0 32.652967464935685 L368.0 36.845815384071074 C368.0 39.35622168705351 368.2049160649308 41.31470341423108 369.3049986648731 42.721577844486596 C370.4266426231 44.14226288573474 371.9581140301696 44.41799020767208 373.9209969180518 44.41799020767208 Z M373.6190197063392 41.714717255511054 C372.5081618396827 41.714717255511054 371.46200911246524 41.50772870285107 370.85804210880167 40.74928550631639 C370.25407539770185 39.97687904574171 370.11387917353517 38.66651426659918 370.11387917353517 37.23202011095692 L370.11387917353517 32.335655656973074 C370.11387917353517 30.887508033181078 370.25407539770185 29.563335636242932 370.8472558709494 28.79097407362336 C371.45122287461294 28.01859754501875 372.5081618396827 27.82549592987508 373.64059218204375 27.82549592987508 L391.13399581549834 27.82549592987508 C392.25556794934124 27.82549592987508 393.30179440260673 28.01859754501875 393.8949731204722 28.79097407362336 C394.49895328950146 29.563335636242932 394.63908895298584 30.873698918786957 394.63908895298584 32.308035931586325 L394.63908895298584 37.23202011095692 C394.63908895298584 38.66651426659918 394.49895328950146 39.97687904574171 393.8949731204722 40.74928550631639 C393.30179440260673 41.52153632064669 392.25556794934124 41.714717255511054 391.13399581549834 41.714717255511054 L373.6190197063392 41.714717255511054 Z M373.19840616592614 39.97687904574171 L390.467680857987 39.97687904574171 C391.1471272438308 39.97687904574171 391.5353814855597 39.852745179446465 391.8157745190204 39.49400453170298 C392.0962892589731 39.13541953020388 392.19335369709637 38.6250854268183 392.19335369709637 37.783784550721876 L392.19335369709637 31.75642863466426 C392.19335369709637 30.901318644173706 392.0962892589731 30.390983044189625 391.8157745190204 30.046051510840265 C391.5353814855597 29.68746650934117 391.1363281331765 29.563335636242932 390.467680857987 29.563335636242932 L373.21997864163075 29.563335636242932 C372.52973431538726 29.563335636242932 372.1306809630041 29.68746650934117 371.8502639393214 30.032240899847636 C371.580645148602 30.390983044189625 371.4727953503175 30.91497061572494 371.4727953503175 31.78404836005101 L371.4727953503175 37.783784550721876 C371.4727953503175 38.63889603781093 371.580645148602 39.13541953020388 371.8502639393214 39.49400453170298 C372.1306809630041 39.852745179446465 372.52973431538726 39.97687904574171 373.19840616592614 39.97687904574171 Z M398.32763122204796 38.500954553720064 C399.2228011946828 38.43206163479683 400.4199600815775 36.96994775376781 400.4199600815775 34.76320128719675 C400.4199600815775 32.57010828877543 399.2228011946828 31.094340939596677 398.32763122204796 31.025449517271944 L398.32763122204796 38.500954553720064 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-16e1d" fill="#4CAF50" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_3" class="path firer commentable non-processed" customid="Wifi"   datasizewidth="20.52px" datasizeheight="14.84px" dataX="338.00" dataY="27.35"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.51532745361328" height="14.835980415344238" viewBox="337.99999969983014 27.352069616317777 20.51532745361328 14.835980415344238" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_3-16e1d" d="M339.3680111744395 33.66264986991885 C339.55258101010236 33.864749670028715 339.8426210262767 33.85594916343692 340.03598087811383 33.645049810409574 C342.2068807461253 31.351049184799223 345.0633112766734 30.13819956779483 348.2537114002696 30.13819956779483 C351.47051113629254 30.13819956779483 354.33581036114606 31.351049184799223 356.4979101994029 33.66264986991885 C356.682511029481 33.84714961051944 356.96371143841657 33.83834910392764 357.14831036114606 33.645049810409574 L358.3787104465953 32.40575003623965 C358.5545107700816 32.229949712753324 358.5545107700816 32.00144934654239 358.41391056561383 31.834449529647856 C356.2957102634898 29.224139928817777 352.34941166424665 27.352069616317777 348.2537114002696 27.352069616317777 C344.16684120678815 27.352069616317777 340.2117611744395 29.21534991264346 338.1023809292308 31.834449529647856 C337.96176093602094 32.00144934654239 337.96176093602094 32.229949712753324 338.1287509777537 32.40575003623965 L339.3680111744395 33.66264986991885 Z M343.04184120678815 37.3188502788544 C343.2527710773936 37.521050214767484 343.5340210773936 37.50344920158389 343.73617142224225 37.28374934196475 C344.8084112980357 36.114749670028715 346.52231091046247 35.28854918479922 348.2625109531871 35.29734969139102 C350.0116106846324 35.28854918479922 351.72541111493024 36.13234972953799 352.8241106846324 37.3100497722626 C353.008610425233 37.521050214767484 353.27231091046247 37.51224970817569 353.47441166424665 37.3100497722626 L354.85431164288434 35.956549406051664 C355.0213114597789 35.79834914207461 355.03891056561383 35.57864928245547 354.8895117619029 35.40284991264346 C353.51841038250836 33.74174952507022 351.01351040387067 32.54644942283633 348.2625109531871 32.54644942283633 C345.5028111317149 32.54644942283633 342.99789112591657 33.74174952507022 341.62680119061383 35.40284991264346 C341.4773809292308 35.57864928245547 341.4949609615794 35.78954958915713 341.6619507648936 35.956549406051664 L343.04184120678815 37.3188502788544 Z M348.2625109531871 42.188050031662016 C348.47351139569196 42.188050031662016 348.65801113629254 42.091349363327055 349.0184113361827 41.748549222946195 L351.17171162152204 39.67434954643252 C351.32991093182477 39.52494883537295 351.3651110508433 39.278849363327055 351.22441166424665 39.10304903984073 C350.60921162152204 38.320849180221586 349.4930111744395 37.688050031662016 348.2625109531871 37.688050031662016 C346.9969107487193 37.688050031662016 345.8631111958018 38.34714961051944 345.2567107059947 39.17335009574893 C345.15121048474225 39.331549406051664 345.20391052746686 39.52494883537295 345.35331123852643 39.67434954643252 L347.5067107059947 41.748549222946195 C347.8582112171641 42.08254885673526 348.0516106464854 42.188050031662016 348.2625109531871 42.188050031662016 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-16e1d" fill="#3AB8F8" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_4" class="path firer commentable non-processed" customid="Alarm"   datasizewidth="16.94px" datasizeheight="18.56px" dataX="307.00" dataY="25.86"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="16.936559677124023" height="18.55930519104004" viewBox="307.0 25.858685699364862 16.936559677124023 18.55930519104004" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_4-16e1d" d="M308.125 29.6555556925747 C308.2568402290344 29.6555556925747 308.3535199165344 29.629195657632074 308.48536014556885 29.532515493294916 L311.59665966033936 27.256145444771967 C311.73725986480713 27.15067574109765 311.8251600265503 27.001265493294916 311.8251600265503 26.851845708749018 C311.8251600265503 26.6584853800747 311.72856044769287 26.491495576760492 311.5703601837158 26.350875821969233 C311.19239044189453 26.034465518853388 310.58594036102295 25.858685699364862 310.02344036102295 25.858685699364862 C308.59960985183716 25.858685699364862 307.4482502937317 26.983685460946283 307.4482502937317 28.381145444771967 C307.4482502937317 28.741495576760492 307.5097699165344 29.07548567380639 307.6064500808716 29.295205560586176 C307.70313024520874 29.514935460946283 307.8964900970459 29.6555556925747 308.125 29.6555556925747 Z M322.811559677124 29.6555556925747 C323.04006004333496 29.6555556925747 323.2246608734131 29.506145444771967 323.3300609588623 29.295205560586176 C323.42675971984863 29.084265676400385 323.47945976257324 28.741495576760492 323.47945976257324 28.381145444771967 C323.47945976257324 26.983685460946283 322.3369598388672 25.858685699364862 320.91305923461914 25.858685699364862 C320.341760635376 25.858685699364862 319.7441596984863 26.034465518853388 319.36626052856445 26.350875821969233 C319.2080593109131 26.491495576760492 319.11136054992676 26.6584853800747 319.11136054992676 26.851845708749018 C319.11136054992676 27.001265493294916 319.1904602050781 27.15067574109765 319.3398609161377 27.256145444771967 L322.4511604309082 29.532515493294916 C322.5830593109131 29.629195657632074 322.67966079711914 29.6555556925747 322.811559677124 29.6555556925747 Z M308.03710985183716 44.192685571572504 C308.3447299003601 44.50028559293481 308.82813024520874 44.49148508634301 309.1357502937317 44.17508646573754 L310.5595703125 42.7600855502102 C311.9394598007202 43.74438616361352 313.635760307312 44.32448526944848 315.4638605117798 44.32448526944848 C317.30076026916504 44.32448526944848 318.98826026916504 43.74438616361352 320.37696075439453 42.7600855502102 L321.80076026916504 44.17508646573754 C322.10836029052734 44.49148508634301 322.591760635376 44.50028559293481 322.8994598388672 44.192685571572504 C323.18946075439453 43.902585473916254 323.1982593536377 43.42798563565942 322.8906593322754 43.12918612088891 L321.5283603668213 41.77568575467797 C323.0136604309082 40.24638506498071 323.936559677124 38.163385835549555 323.936559677124 35.860685792824945 C323.936559677124 31.18485590543481 320.1484603881836 27.396765676400385 315.4638605117798 27.396765676400385 C310.78808975219727 27.396765676400385 307.0 31.18485590543481 307.0 35.860685792824945 C307.0 38.163385835549555 307.91407012939453 40.24638506498071 309.4082102775574 41.77568575467797 L308.0458998680115 43.12918612088891 C307.7382802963257 43.42798563565942 307.74706983566284 43.902585473916254 308.03710985183716 44.192685571572504 Z M315.4638605117798 42.55788561429711 C311.7636604309082 42.55788561429711 308.76661014556885 39.56078478421899 308.76661014556885 35.860685792824945 C308.76661014556885 32.160445657632074 311.7636604309082 29.163375821969233 315.4638605117798 29.163375821969233 C319.16406059265137 29.163375821969233 322.16115951538086 32.160445657632074 322.16115951538086 35.860685792824945 C322.16115951538086 39.56078478421899 319.16406059265137 42.55788561429711 315.4638605117798 42.55788561429711 Z M311.6494598388672 36.95048567380639 L315.4638605117798 36.95048567380639 C315.85056018829346 36.95048567380639 316.1494598388672 36.65168520536157 316.1494598388672 36.26488539304467 L316.1494598388672 31.15848585691186 C316.1494598388672 30.771765199563227 315.85056018829346 30.472945657632074 315.4638605117798 30.472945657632074 C315.0771598815918 30.472945657632074 314.7783603668213 30.771765199563227 314.7783603668213 31.15848585691186 L314.7783603668213 35.579385248086176 L311.6494598388672 35.579385248086176 C311.2627000808716 35.579385248086176 310.96387004852295 35.88698526944848 310.96387004852295 36.26488539304467 C310.96387004852295 36.65168520536157 311.2627000808716 36.95048567380639 311.6494598388672 36.95048567380639 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-16e1d" fill="#999999" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Table date &amp; time" datasizewidth="0.00px" datasizeheight="44.00px" >\
        <div id="s-Path_5" class="path firer ie-background commentable non-processed" customid="Line"   datasizewidth="190.50px" datasizeheight="3.00px" dataX="-15.03" dataY="45.05"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="190.497802734375" height="2.0" viewBox="-15.025361739098344 45.04935869082384 190.497802734375 2.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_5-16e1d" d="M-14.025422774254366 46.04944261416358 L174.4723582643237 46.04944261416358 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-16e1d" fill="none" stroke-width="1.0" stroke="#3C3C4332" stroke-linecap="square" opacity="0.8"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Date_1" class="date firer commentable non-processed" customid="Date-Time Input" value="1647734400000" format="MM/dd/yy"  datasizewidth="70.82px" datasizeheight="21.69px" dataX="68.00" dataY="22.25" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="date"  tabindex="-1"  /></div></div></div></div></div>\
        <div id="s-Date_2" class="time firer commentable non-processed" customid="Time Input" value="15660000" format="HH:mm"  datasizewidth="43.12px" datasizeheight="21.04px" dataX="17.00" dataY="22.57" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="time"  tabindex="-1"  /></div></div></div></div></div>\
      </div>\
\
      <div id="s-Text_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Appliance Manager"   datasizewidth="254.95px" datasizeheight="96.00px" dataX="87.52" dataY="132.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">Appliance Manager<br /><br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_panel_1" class="dynamicpanel firer ie-background commentable non-processed" customid="Dynamic panel 1" datasizewidth="341.73px" datasizeheight="475.38px" dataX="44.13" dataY="212.00" >\
        <div id="s-Panel_1" class="panel default firer ie-background commentable non-processed" customid="Panel 1"  datasizewidth="341.73px" datasizeheight="475.38px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="122.00px" datasizeheight="109.00px" datasizewidthpx="122.0" datasizeheightpx="109.00000000000006" dataX="183.00" dataY="38.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_2_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="129.00px" datasizeheight="119.00px" datasizewidthpx="129.0" datasizeheightpx="119.00000000000006" dataX="15.00" dataY="260.19" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_3_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="122.00px" datasizeheight="119.00px" datasizewidthpx="122.00000000000011" datasizeheightpx="119.00000000000006" dataX="183.00" dataY="260.19" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_4_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="122.00px" datasizeheight="109.00px" datasizewidthpx="122.0" datasizeheightpx="109.00000000000006" dataX="22.00" dataY="38.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_1_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Text_3" class="richtext autofit firer ie-background commentable non-processed" customid="ON/OFF"   datasizewidth="83.10px" datasizeheight="25.00px" dataX="202.45" dataY="194.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Text_3_0">ON/OFF</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Text_4" class="richtext autofit firer ie-background commentable non-processed" customid="ON/OFF"   datasizewidth="83.10px" datasizeheight="25.00px" dataX="37.95" dataY="427.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Text_4_0">ON/OFF</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Text_5" class="richtext autofit firer ie-background commentable non-processed" customid="ON/OFF"   datasizewidth="83.10px" datasizeheight="25.00px" dataX="202.45" dataY="427.00" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Text_5_0">ON/OFF</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_8" class="inputIOS checkbox firer commentable non-processed checked" customid="Toggle"  datasizewidth="51.00px" datasizeheight="31.00px" dataX="96.00" dataY="368.00"   value="true"  checked="checked" tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Input_9" class="inputIOS checkbox firer commentable non-processed checked" customid="Toggle"  datasizewidth="51.00px" datasizeheight="31.00px" dataX="96.00" dataY="597.50"   value="true"  checked="checked" tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Input_10" class="inputIOS checkbox firer commentable non-processed checked" customid="Toggle"  datasizewidth="51.00px" datasizeheight="31.00px" dataX="256.00" dataY="368.00"   value="true"  checked="checked" tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Input_11" class="inputIOS checkbox firer commentable non-processed checked" customid="Toggle"  datasizewidth="51.00px" datasizeheight="31.00px" dataX="256.00" dataY="598.00"   value="true"  checked="checked" tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext autofit firer ie-background commentable non-processed" customid="ON/OFF"   datasizewidth="83.10px" datasizeheight="25.00px" dataX="79.95" dataY="408.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">ON/OFF</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;