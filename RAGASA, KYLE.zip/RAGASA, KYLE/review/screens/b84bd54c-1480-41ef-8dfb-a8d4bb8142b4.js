var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1730547994919.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-b84bd54c-1480-41ef-8dfb-a8d4bb8142b4" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Accessibility Settings"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/b84bd54c-1480-41ef-8dfb-a8d4bb8142b4/style-1730547994919.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/b84bd54c-1480-41ef-8dfb-a8d4bb8142b4/fonts-1730547994919.css" />\
      <div class="freeLayout">\
      <div id="s-Path_1" class="path firer commentable pin vpin-end hpin-center non-processed-pin non-processed" customid="Home indicator"   datasizewidth="135.00px" datasizeheight="5.00px" dataX="-0.00" dataY="27.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="135.0" height="5.0" viewBox="147.49999999999983 900.0000000000002 135.0 5.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-b84bd" d="M149.99999999999983 900.0000000000002 L280.00000000000006 900.0000000000002 C281.3714594258872 900.0000000000002 282.50000000000006 901.128540574113 282.50000000000006 902.5000000000001 L282.50000000000006 902.5000000000001 C282.50000000000006 903.8714594258872 281.3714594258872 905.0 280.00000000000006 905.0 L149.99999999999983 905.0 C148.62854057411266 905.0 147.49999999999983 903.8714594258872 147.49999999999983 902.5000000000001 L147.49999999999983 902.5000000000001 C147.49999999999983 901.128540574113 148.62854057411266 900.0000000000002 149.99999999999983 900.0000000000002 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-b84bd" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer commentable non-processed" customid="Battery full"   datasizewidth="32.42px" datasizeheight="19.30px" dataX="384.00" dataY="25.12"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="32.419960021972656" height="19.295860290527344" viewBox="384.00000000000034 25.122129440307447 32.419960021972656 19.295860290527344" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-b84bd" d="M389.92099691805214 44.41799020767195 L406.8320069012388 44.41799020767195 C408.7948775014463 44.41799020767195 410.3370976982168 44.14226288573461 411.4479924278973 42.72157784448647 C412.548090387433 41.30089280323833 412.75301603382434 39.356221687053385 412.75301603382434 36.845815384070946 L412.75301603382434 32.69424065847204 C412.75301603382434 30.170182383938375 412.548090387433 28.225478342586342 411.4479924278973 26.818633844300905 C410.32630092807193 25.3979809799206 408.7948775014463 25.122129440307447 406.8320069012388 25.122129440307447 L389.88865049217 25.122129440307447 C387.95811403016995 25.122129440307447 386.4158563852481 25.3979809799206 385.31577261505106 26.818633844300905 C384.2049160649311 28.23927249099543 384.00000000000034 30.183992994931003 384.00000000000034 32.65296746493556 L384.00000000000034 36.845815384070946 C384.00000000000034 39.356221687053385 384.2049160649311 41.314703414230955 385.30499866487344 42.72157784448647 C386.42664262310035 44.14226288573461 387.95811403016995 44.41799020767195 389.92099691805214 44.41799020767195 Z M389.61901970633954 41.71471725551093 C388.50816183968305 41.71471725551093 387.4620091124656 41.50772870285094 386.858042108802 40.74928550631626 C386.2540753977022 39.97687904574158 386.1138791735355 38.66651426659905 386.1138791735355 37.23202011095679 L386.1138791735355 32.335655656972946 C386.1138791735355 30.88750803318095 386.2540753977022 29.563335636242805 386.84725587094977 28.790974073623232 C387.4512228746133 28.018597545018622 388.50816183968305 27.82549592987495 389.6405921820441 27.82549592987495 L407.1339958154987 27.82549592987495 C408.2555679493416 27.82549592987495 409.3017944026071 28.018597545018622 409.8949731204725 28.790974073623232 C410.4989532895018 29.563335636242805 410.6390889529862 30.87369891878683 410.6390889529862 32.3080359315862 L410.6390889529862 37.23202011095679 C410.6390889529862 38.66651426659905 410.4989532895018 39.97687904574158 409.8949731204725 40.74928550631626 C409.3017944026071 41.52153632064656 408.2555679493416 41.71471725551093 407.1339958154987 41.71471725551093 L389.61901970633954 41.71471725551093 Z M389.1984061659265 39.97687904574158 L406.4676808579873 39.97687904574158 C407.14712724383116 39.97687904574158 407.53538148556004 39.85274517944634 407.81577451902075 39.49400453170285 C408.09628925897346 39.135419530203755 408.1933536970967 38.625085426818174 408.1933536970967 37.78378455072175 L408.1933536970967 31.756428634664132 C408.1933536970967 30.90131864417358 408.09628925897346 30.390983044189497 407.81577451902075 30.046051510840137 C407.53538148556004 29.687466509341043 407.13632813317685 29.563335636242805 406.4676808579873 29.563335636242805 L389.2199786416311 29.563335636242805 C388.5297343153876 29.563335636242805 388.13068096300447 29.687466509341043 387.85026393932174 30.03224089984751 C387.58064514860234 30.390983044189497 387.4727953503178 30.914970615724812 387.4727953503178 31.784048360050882 L387.4727953503178 37.78378455072175 C387.4727953503178 38.6388960378108 387.58064514860234 39.135419530203755 387.85026393932174 39.49400453170285 C388.13068096300447 39.85274517944634 388.5297343153876 39.97687904574158 389.1984061659265 39.97687904574158 Z M414.3276312220483 38.500954553719936 C415.22280119468314 38.4320616347967 416.41996008157787 36.969947753767684 416.41996008157787 34.76320128719662 C416.41996008157787 32.5701082887753 415.22280119468314 31.09434093959655 414.3276312220483 31.025449517271817 L414.3276312220483 38.500954553719936 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-b84bd" fill="#4CAF50" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_3" class="path firer commentable non-processed" customid="Wifi"   datasizewidth="20.52px" datasizeheight="14.84px" dataX="354.00" dataY="27.35"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="20.51532745361328" height="14.835980415344238" viewBox="353.99999969983 27.352069616317834 20.51532745361328 14.835980415344238" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_3-b84bd" d="M355.3680111744394 33.66264986991889 C355.55258101010224 33.86474967002874 355.84262102627656 33.85594916343695 356.0359808781137 33.64504981040961 C358.2068807461252 31.351049184799265 361.0633112766733 30.138199567794874 364.2537114002694 30.138199567794874 C367.4705111362924 30.138199567794874 370.3358103611459 31.351049184799265 372.4979101994027 33.66264986991889 C372.68251102948085 33.847149610519466 372.9637114384164 33.83834910392767 373.1483103611459 33.64504981040961 L374.3787104465951 32.40575003623969 C374.55451077008144 32.22994971275337 374.55451077008144 32.00144934654243 374.41391056561366 31.834449529647898 C372.29571026348964 29.224139928817827 368.3494116642465 27.352069616317834 364.2537114002694 27.352069616317834 C360.16684120678804 27.352069616317834 356.2117611744394 29.21534991264351 354.10238092923066 31.834449529647898 C353.9617609360208 32.00144934654243 353.9617609360208 32.22994971275337 354.1287509777536 32.40575003623969 L355.3680111744394 33.66264986991889 Z M359.04184120678804 37.31885027885441 C359.2527710773935 37.5210502147675 359.5340210773935 37.503449201583905 359.73617142224214 37.283749341964764 C360.8084112980356 36.114749670028736 362.5223109104623 35.28854918479925 364.2625109531869 35.29734969139105 C366.0116106846322 35.28854918479925 367.72541111493007 36.132349729538014 368.8241106846322 37.310049772262616 C369.0086104252328 37.5210502147675 369.2723109104623 37.5122497081757 369.4744116642465 37.310049772262616 L370.85431164288417 35.95654940605169 C371.0213114597787 35.79834914207464 371.03891056561366 35.5786492824555 370.8895117619027 35.40284991264349 C369.5184103825082 33.74174952507025 367.0135104038705 32.54644942283637 364.2625109531869 32.54644942283637 C361.5028111317148 32.54644942283637 358.99789112591645 33.74174952507025 357.6268011906137 35.40284991264349 C357.47738092923066 35.5786492824555 357.4949609615793 35.78954958915716 357.6619507648935 35.95654940605169 L359.04184120678804 37.31885027885441 Z M364.2625109531869 42.188050031662016 C364.4735113956918 42.188050031662016 364.6580111362924 42.091349363327055 365.0184113361825 41.748549222946195 L367.17171162152187 39.67434954643254 C367.3299109318246 39.52494883537297 367.36511105084315 39.27884936332707 367.2244116642465 39.10304903984074 C366.60921162152187 38.3208491802216 365.49301117443935 37.68805003166203 364.2625109531869 37.68805003166203 C362.99691074871913 37.68805003166203 361.8631111958017 38.34714961051945 361.2567107059946 39.173350095748944 C361.15121048474214 39.33154940605168 361.20391052746675 39.52494883537297 361.3533112385263 39.67434954643254 L363.5067107059945 41.748549222946195 C363.85821121716396 42.08254885673526 364.05161064648524 42.188050031662016 364.2625109531869 42.188050031662016 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-b84bd" fill="#3AB8F8" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_4" class="path firer commentable non-processed" customid="Alarm"   datasizewidth="16.94px" datasizeheight="18.56px" dataX="323.00" dataY="25.86"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="16.936559677124023" height="18.55930519104004" viewBox="323.0000000000001 25.85868569936474 16.936559677124023 18.55930519104004" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_4-b84bd" d="M324.1250000000001 29.655555692574577 C324.25684022903454 29.655555692574577 324.35351991653454 29.62919565763195 324.48536014556896 29.53251549329479 L327.5966596603395 27.256145444771846 C327.7372598648073 27.15067574109753 327.82516002655046 27.001265493294795 327.82516002655046 26.851845708748897 C327.82516002655046 26.65848538007458 327.72856044769304 26.49149557676037 327.570360183716 26.35087582196911 C327.1923904418947 26.034465518853267 326.5859403610231 25.85868569936474 326.0234403610231 25.85868569936474 C324.5996098518373 25.85868569936474 323.4482502937318 26.983685460946162 323.4482502937318 28.381145444771843 C323.4482502937318 28.741495576760368 323.50976991653454 29.075485673806266 323.6064500808717 29.29520556058605 C323.70313024520885 29.51493546094616 323.896490097046 29.655555692574577 324.1250000000001 29.655555692574577 Z M338.81155967712436 29.655555692574577 C339.0400600433353 29.655555692574577 339.2246608734134 29.506145444771843 339.33006095886265 29.29520556058605 C339.426759719849 29.08426567640026 339.4794597625736 28.741495576760368 339.4794597625736 28.381145444771843 C339.4794597625736 26.983685460946162 338.33695983886753 25.85868569936474 336.9130592346194 25.85868569936474 C336.34176063537626 25.85868569936474 335.7441596984866 26.034465518853267 335.36626052856474 26.35087582196911 C335.20805931091337 26.49149557676037 335.11136054992704 26.65848538007458 335.11136054992704 26.851845708748897 C335.11136054992704 27.001265493294795 335.1904602050784 27.15067574109753 335.339860916138 27.256145444771846 L338.45116043090854 29.53251549329479 C338.5830593109134 29.62919565763195 338.6796607971195 29.655555692574577 338.81155967712436 29.655555692574577 Z M324.0371098518373 44.19268557157236 C324.3447299003602 44.50028559293467 324.82813024520885 44.49148508634287 325.1357502937318 44.1750864657374 L326.55957031250017 42.760085550210064 C327.9394598007204 43.74438616361338 329.63576030731224 44.32448526944834 331.46386051178 44.32448526944834 C333.30076026916527 44.32448526944834 334.9882602691653 43.74438616361338 336.3769607543948 42.760085550210064 L337.8007602691653 44.1750864657374 C338.1083602905277 44.49148508634287 338.5917606353763 44.50028559293467 338.89945983886753 44.19268557157236 C339.1894607543949 43.90258547391611 339.19825935363804 43.427985635659276 338.89065933227573 43.12918612088877 L337.5283603668216 41.77568575467784 C339.01366043090854 40.24638506498057 339.93655967712436 38.16338583554942 339.93655967712436 35.86068579282481 C339.93655967712436 31.18485590543468 336.1484603881839 27.396765676400264 331.46386051178 27.396765676400264 C326.78808975219744 27.396765676400264 323.0000000000001 31.18485590543468 323.0000000000001 35.86068579282481 C323.0000000000001 38.16338583554942 323.91407012939464 40.24638506498057 325.40821027755754 41.77568575467784 L324.0458998680116 43.12918612088877 C323.7382802963258 43.427985635659276 323.74706983566296 43.90258547391611 324.0371098518373 44.19268557157236 Z M331.46386051178 42.55788561429698 C327.7636604309084 42.55788561429698 324.76661014556896 39.56078478421885 324.76661014556896 35.86068579282481 C324.76661014556896 32.160445657631946 327.7636604309084 29.163375821969108 331.46386051178 29.163375821969108 C335.16406059265165 29.163375821969108 338.1611595153812 32.160445657631946 338.1611595153812 35.86068579282481 C338.1611595153812 39.56078478421885 335.16406059265165 42.55788561429698 331.46386051178 42.55788561429698 Z M327.64945983886736 36.950485673806256 L331.46386051178 36.950485673806256 C331.8505601882937 36.950485673806256 332.1494598388674 36.65168520536143 332.1494598388674 36.26488539304454 L332.1494598388674 31.15848585691173 C332.1494598388674 30.7717651995631 331.8505601882937 30.472945657631946 331.46386051178 30.472945657631946 C331.077159881592 30.472945657631946 330.7783603668215 30.7717651995631 330.7783603668215 31.15848585691173 L330.7783603668215 35.57938524808604 L327.64945983886736 35.57938524808604 C327.26270008087175 35.57938524808604 326.9638700485231 35.886985269448346 326.9638700485231 36.26488539304454 C326.9638700485231 36.65168520536143 327.26270008087175 36.950485673806256 327.64945983886736 36.950485673806256 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-b84bd" fill="#999999" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Table date &amp; time" datasizewidth="0.00px" datasizeheight="44.00px" >\
        <div id="s-Path_5" class="path firer ie-background commentable non-processed" customid="Line"   datasizewidth="190.50px" datasizeheight="3.00px" dataX="-0.03" dataY="45.05"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="190.497802734375" height="2.0" viewBox="-0.02536173909822992 45.04935869082374 190.497802734375 2.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_5-b84bd" d="M0.9745772257456338 46.04944261416358 L189.4723582643237 46.04944261416358 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-b84bd" fill="none" stroke-width="1.0" stroke="#3C3C4332" stroke-linecap="square" opacity="0.8"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Date_1" class="date firer commentable non-processed" customid="Date-Time Input" value="1647734400000" format="MM/dd/yy"  datasizewidth="70.82px" datasizeheight="21.69px" dataX="83.00" dataY="22.25" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="date"  tabindex="-1"  /></div></div></div></div></div>\
        <div id="s-Date_2" class="time firer commentable non-processed" customid="Time Input" value="15660000" format="HH:mm"  datasizewidth="43.12px" datasizeheight="21.04px" dataX="32.00" dataY="22.57" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="time"  tabindex="-1"  /></div></div></div></div></div>\
      </div>\
\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="Accessibility Settings"   datasizewidth="274.79px" datasizeheight="64.00px" dataX="77.60" dataY="76.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">Accessibility Settings<br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="richtext autofit firer ie-background commentable non-processed" customid="Font Size Adjustment"   datasizewidth="230.30px" datasizeheight="56.00px" dataX="100.00" dataY="140.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Font Size Adjustment<br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="81.50px" datasizeheight="60.00px" datasizewidthpx="81.49999999999929" datasizeheightpx="60.0" dataX="133.50" dataY="196.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="79.50px" datasizeheight="59.00px" datasizewidthpx="79.49999999999989" datasizeheightpx="59.00000000000014" dataX="215.00" dataY="196.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Contrast"   datasizewidth="132.25px" datasizeheight="84.00px" dataX="158.88" dataY="271.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">Contrast<br /><br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 3"   datasizewidth="159.00px" datasizeheight="82.00px" datasizewidthpx="159.0" datasizeheightpx="82.0" dataX="135.50" dataY="303.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_4" class="richtext manualfit firer ie-background commentable non-processed" customid="Text to Speech"   datasizewidth="208.94px" datasizeheight="84.00px" dataX="110.53" dataY="458.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0">Text to Speech<br /><br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Table_2" class="table firer ie-background commentable non-processed" customid="Slider"  datasizewidth="430.00px" datasizeheight="44.00px" dataX="9.00" dataY="542.00" originalwidth="430.0px" originalheight="44.0px" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <table summary="">\
              <tbody>\
                <tr>\
                  <td id="s-Cell_4" customid="Cell" class="cellcontainer firer ie-background non-processed"    datasizewidth="430.00px" datasizeheight="44.00px" dataX="0.00" dataY="0.00" originalwidth="430.0px" originalheight="44.0px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_4 Table_2" valign="middle" align="center" hSpacing="0" vSpacing="0"><div id="s-Dynamic_Panel_2" class="percentage dynamicpanel firer ie-background commentable non-processed-percentage non-processed" customid="Slider-bar" datasizewidth="92.00%" datasizeheight="44.00px" dataX="14.00" dataY="0.00" >\
                              <div id="s-Panel_2" class="percentage panel default firer ie-background commentable non-processed-percentage non-processed" customid="Panel 1"  datasizewidth="92.00%" datasizeheight="44.00px" >\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                                	<div class="layoutWrapper scrollable">\
                                	  <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_6" class="percentage rectangle manualfit firer commentable non-processed-percentage non-processed" customid="Line"   datasizewidth="100.00%" datasizeheight="4.00px" datasizewidthpx="395.59999999999997" datasizeheightpx="4.0" dataX="0.00" dataY="21.00" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_6_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Rectangle_7" class="rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="170.00px" datasizeheight="4.00px" datasizewidthpx="170.0" datasizeheightpx="4.0" dataX="1.00" dataY="21.00" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_7_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="shapewrapper-s-Ellipse_2" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="30.00px" datasizeheight="30.00px" datasizewidthpx="30.0" datasizeheightpx="30.0" dataX="157.00" dataY="7.00" >\
                                          <div class="backgroundLayer">\
                                            <div class="colorLayer"></div>\
                                            <div class="imageLayer"></div>\
                                          </div>\
                                          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
                                              <g>\
                                                  <g clip-path="url(#clip-s-Ellipse_2)">\
                                                          <ellipse id="s-Ellipse_2" class="ellipse shape non-processed-shape manualfit firer dragstart drag dragend commentable non-processed" customid="Ellipse" cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                                          </ellipse>\
                                                  </g>\
                                              </g>\
                                              <defs>\
                                                  <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                                                          <ellipse cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                                          </ellipse>\
                                                  </clipPath>\
                                              </defs>\
                                          </svg>\
                                          <div class="paddingLayer">\
                                              <div id="shapert-s-Ellipse_2" class="content firer" >\
                                                  <div class="valign">\
                                                      <span id="rtr-s-Ellipse_2_0"></span>\
                                                  </div>\
                                              </div>\
                                          </div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </div></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
              </tbody>\
            </table>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_8" class="inputIOS checkbox firer commentable non-processed checked" customid="Toggle"  datasizewidth="51.00px" datasizeheight="31.00px" dataX="204.50" dataY="500.00"   value="true"  checked="checked" tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Text_5" class="richtext autofit firer ie-background commentable non-processed" customid="Speech Speed Slider"   datasizewidth="150.33px" datasizeheight="36.00px" dataX="139.84" dataY="594.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_5_0">Speech Speed Slider<br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Table_1" class="table firer ie-background commentable non-processed" customid="Slider icon"  datasizewidth="430.00px" datasizeheight="44.00px" dataX="0.00" dataY="396.00" originalwidth="430.0px" originalheight="44.0px" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <table summary="">\
              <tbody>\
                <tr>\
                  <td id="s-Cell_3" customid="Cell" class="cellcontainer firer ie-background non-processed"    datasizewidth="430.00px" datasizeheight="44.00px" dataX="0.00" dataY="0.00" originalwidth="430.0px" originalheight="44.0px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <div class="center ghostHLayout">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout horizontal insertionpoint verticalalign Cell_3 Table_1" valign="middle" align="center" hSpacing="3" vSpacing="0"><div class="relativeLayoutWrapper s-Group_2 "><div class="relativeLayoutWrapperResponsive">\
                            <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Left icon" datasizewidth="0.00px" datasizeheight="0.00px" >\
                              <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="32.00px" datasizeheight="38.00px" datasizewidthpx="32.0" datasizeheightpx="38.0" dataX="398.00" dataY="645.00" >\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                                  <div class="paddingLayer">\
                                    <div class="content">\
                                      <div class="valign">\
                                        <span id="rtr-s-Rectangle_4_0"></span>\
                                      </div>\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                              <div id="s-Path_6" class="path firer commentable non-processed" customid="Light icon"   datasizewidth="19.59px" datasizeheight="19.59px" dataX="404.21" dataY="654.21"  >\
                                <div class="borderLayer">\
                                	<div class="imageViewport">\
                                  	<?xml version="1.0" encoding="UTF-8"?>\
                                  	<svg xmlns="http://www.w3.org/2000/svg" width="19.589799880981445" height="19.58982276916504" viewBox="404.2051000595093 654.2050885558128 19.589799880981445 19.58982276916504" preserveAspectRatio="none">\
                                  	  <g>\
                                  	    <defs>\
                                  	      <path id="s-Path_6-b84bd" d="M414.00002002716064 656.4902406334877 C414.625 656.4902406334877 415.1426000595093 655.9726704955101 415.1426000595093 655.3476704955101 C415.1426000595093 654.7226665616035 414.625 654.2050885558128 414.00002002716064 654.2050885558128 C413.37502002716064 654.2050885558128 412.857439994812 654.7226665616035 412.857439994812 655.3476704955101 C412.857439994812 655.9726704955101 413.37502002716064 656.4902406334877 414.00002002716064 656.4902406334877 Z M407.87698006629944 659.0195403695107 C408.5117402076721 659.0195403695107 409.01954984664917 658.501960337162 409.01954984664917 657.8769605755806 C409.01954984664917 657.2519605755806 408.5117402076721 656.7343905568123 407.87698006629944 656.7343905568123 C407.25198006629944 656.7343905568123 406.7344000339508 657.2519605755806 406.7344000339508 657.8769605755806 C406.7344000339508 658.501960337162 407.25198006629944 659.0195403695107 407.87698006629944 659.0195403695107 Z M420.1231002807617 659.0195403695107 C420.7480993270874 659.0195403695107 421.26559925079346 658.501960337162 421.26559925079346 657.8769605755806 C421.26559925079346 657.2519605755806 420.7480993270874 656.7343905568123 420.1231002807617 656.7343905568123 C419.4981002807617 656.7343905568123 418.98050022125244 657.2519605755806 418.98050022125244 657.8769605755806 C418.98050022125244 658.501960337162 419.4981002807617 659.0195403695107 420.1231002807617 659.0195403695107 Z M414.00002002716064 668.9707108139992 C416.71490001678467 668.9707108139992 418.98050022125244 666.7148104310036 418.98050022125244 664.0000105500221 C418.98050022125244 661.275400698185 416.71490001678467 659.0195403695107 414.00002002716064 659.0195403695107 C411.2851800918579 659.0195403695107 409.02932024002075 661.275400698185 409.02932024002075 664.0000105500221 C409.02932024002075 666.7148104310036 411.2851800918579 668.9707108139992 414.00002002716064 668.9707108139992 Z M405.3476800918579 665.1426106095314 C405.9726800918579 665.1426106095314 406.49026012420654 664.6250105500221 406.49026012420654 664.0000105500221 C406.49026012420654 663.3652401566505 405.9726800918579 662.8574305176735 405.3476800918579 662.8574305176735 C404.7226780653 662.8574305176735 404.2051000595093 663.3652401566505 404.2051000595093 664.0000105500221 C404.2051000595093 664.6250105500221 404.7226780653 665.1426106095314 405.3476800918579 665.1426106095314 Z M422.65240001678467 665.1426106095314 C423.27740001678467 665.1426106095314 423.7948999404907 664.6250105500221 423.7948999404907 664.0000105500221 C423.7948999404907 663.3652401566505 423.27740001678467 662.8574305176735 422.65240001678467 662.8574305176735 C422.02740001678467 662.8574305176735 421.5098009109497 663.3652401566505 421.5098009109497 664.0000105500221 C421.5098009109497 664.6250105500221 422.02740001678467 665.1426106095314 422.65240001678467 665.1426106095314 Z M420.1231002807617 671.2656107544899 C420.7480993270874 671.2656107544899 421.26559925079346 670.7480097413063 421.26559925079346 670.1230097413063 C421.26559925079346 669.4883108735085 420.7480993270874 668.9805107712746 420.1231002807617 668.9805107712746 C419.4981002807617 668.9805107712746 418.98050022125244 669.4883108735085 418.98050022125244 670.1230097413063 C418.98050022125244 670.7480097413063 419.4981002807617 671.2656107544899 420.1231002807617 671.2656107544899 Z M407.87698006629944 671.2656107544899 C408.5117402076721 671.2656107544899 409.01954984664917 670.7480097413063 409.01954984664917 670.1230097413063 C409.01954984664917 669.4883108735085 408.5117402076721 668.9805107712746 407.87698006629944 668.9805107712746 C407.25198006629944 668.9805107712746 406.7344000339508 669.4883108735085 406.7344000339508 670.1230097413063 C406.7344000339508 670.7480097413063 407.25198006629944 671.2656107544899 407.87698006629944 671.2656107544899 Z M414.00002002716064 673.7949114441872 C414.625 673.7949114441872 415.1426000595093 673.2773104310036 415.1426000595093 672.6523104310036 C415.1426000595093 672.0176096558571 414.625 671.5098105072975 414.00002002716064 671.5098105072975 C413.37502002716064 671.5098105072975 412.857439994812 672.0176096558571 412.857439994812 672.6523104310036 C412.857439994812 673.2773104310036 413.37502002716064 673.7949114441872 414.00002002716064 673.7949114441872 Z "></path>\
                                  	    </defs>\
                                  	    <g style="mix-blend-mode:normal">\
                                  	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-b84bd" fill="#3C3C43" fill-opacity="0.3"></use>\
                                  	    </g>\
                                  	  </g>\
                                  	</svg>\
\
                                  </div>\
                                </div>\
                              </div>\
                            </div>\
                            </div></div><div id="s-Dynamic_Panel_1" class="percentage dynamicpanel firer ie-background commentable non-processed-percentage non-processed" customid="Slider-bar" datasizewidth="80.00%" datasizeheight="44.00px" dataX="36.00" dataY="0.00" >\
                              <div id="s-Panel_1" class="percentage panel default firer ie-background commentable non-processed-percentage non-processed" customid="Panel 2"  datasizewidth="80.00%" datasizeheight="44.00px" >\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                                	<div class="layoutWrapper scrollable">\
                                	  <div class="paddingLayer">\
                                      <div class="freeLayout">\
                                      <div id="s-Rectangle_5" class="percentage rectangle manualfit firer commentable non-processed-percentage non-processed" customid="Line"   datasizewidth="100.00%" datasizeheight="4.00px" datasizewidthpx="344.0" datasizeheightpx="4.0" dataX="0.00" dataY="21.00" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_5_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="s-Rectangle_8" class="rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="170.00px" datasizeheight="4.00px" datasizewidthpx="170.0" datasizeheightpx="4.0" dataX="1.00" dataY="21.00" >\
                                        <div class="backgroundLayer">\
                                          <div class="colorLayer"></div>\
                                          <div class="imageLayer"></div>\
                                        </div>\
                                        <div class="borderLayer">\
                                          <div class="paddingLayer">\
                                            <div class="content">\
                                              <div class="valign">\
                                                <span id="rtr-s-Rectangle_8_0"></span>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                      </div>\
                                      <div id="shapewrapper-s-Ellipse_1" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="30.00px" datasizeheight="30.00px" datasizewidthpx="30.0" datasizeheightpx="30.0" dataX="171.20" dataY="7.00" >\
                                          <div class="backgroundLayer">\
                                            <div class="colorLayer"></div>\
                                            <div class="imageLayer"></div>\
                                          </div>\
                                          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                                              <g>\
                                                  <g clip-path="url(#clip-s-Ellipse_1)">\
                                                          <ellipse id="s-Ellipse_1" class="ellipse shape non-processed-shape manualfit firer dragstart drag dragend commentable non-processed" customid="Ellipse" cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                                          </ellipse>\
                                                  </g>\
                                              </g>\
                                              <defs>\
                                                  <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                                                          <ellipse cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                                          </ellipse>\
                                                  </clipPath>\
                                              </defs>\
                                          </svg>\
                                          <div class="paddingLayer">\
                                              <div id="shapert-s-Ellipse_1" class="content firer" >\
                                                  <div class="valign">\
                                                      <span id="rtr-s-Ellipse_1_0"></span>\
                                                  </div>\
                                              </div>\
                                          </div>\
                                      </div>\
                                      </div>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                            </div><div class="relativeLayoutWrapper s-Group_3 "><div class="relativeLayoutWrapperResponsive">\
                            <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Right icon" datasizewidth="0.00px" datasizeheight="0.00px" >\
                              <div id="s-Rectangle_9" class="rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="38.00px" datasizeheight="38.00px" datasizewidthpx="38.0" datasizeheightpx="38.0" dataX="328.98" dataY="645.09" >\
                                <div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div>\
                                <div class="borderLayer">\
                                  <div class="paddingLayer">\
                                    <div class="content">\
                                      <div class="valign">\
                                        <span id="rtr-s-Rectangle_9_0"></span>\
                                      </div>\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                              <div id="s-Path_7" class="path firer commentable non-processed" customid="Light icon"   datasizewidth="21.14px" datasizeheight="21.20px" dataX="337.41" dataY="653.49"  >\
                                <div class="borderLayer">\
                                	<div class="imageViewport">\
                                  	<?xml version="1.0" encoding="UTF-8"?>\
                                  	<svg xmlns="http://www.w3.org/2000/svg" width="21.142578125" height="21.20118522644043" viewBox="337.40524917841003 653.4882135093212 21.142578125 21.20118522644043" preserveAspectRatio="none">\
                                  	  <g>\
                                  	    <defs>\
                                  	      <path id="s-Path_7-b84bd" d="M348.8310274481778 654.3475895226002 C348.8310274481778 653.8788385093212 348.44042724371 653.4882135093212 347.97162765264557 653.4882135093212 C347.5126270651822 653.4882135093212 347.1220268607144 653.8788385093212 347.1220268607144 654.3475895226002 L347.1220268607144 656.3983695805073 C347.1220268607144 656.8573494255543 347.5126270651822 657.247979670763 347.97162765264557 657.247979670763 C348.44042724371 657.247979670763 348.8310274481778 656.8573494255543 348.8310274481778 656.3983695805073 L348.8310274481778 654.3475895226002 Z M352.7958263754849 658.0682893097401 C352.47362750768707 658.4003196060658 352.47362750768707 658.9374294579029 352.7958263754849 659.2694592773914 C353.1279262900357 659.591729670763 353.67482799291656 659.6014995872974 354.0068268179898 659.2694592773914 L355.4619278311734 657.8143897354603 C355.79392665624664 657.4823494255543 355.79392665624664 656.92570951581 355.4619278311734 656.6034496128559 C355.139627873898 656.2714195549488 354.5927280783658 656.2714195549488 354.2705273032193 656.6034496128559 L352.7958263754849 658.0682893097401 Z M341.9364971518521 659.2694592773914 C342.26852697134063 659.591729670763 342.8154072165494 659.591729670763 343.1376671195035 659.2694592773914 C343.4697069525723 658.9569592773914 343.4697069525723 658.3905597031116 343.1474370360379 658.0682893097401 L341.69235700368927 656.6034496128559 C341.37985700368927 656.2811794579029 340.8232173323636 656.2714195549488 340.4911872744565 656.6034496128559 C340.1689171195035 656.92570951581 340.1689171195035 657.4823494255543 340.4814171195035 657.8046193420887 L341.9364971518521 659.2694592773914 Z M347.97162765264557 659.1034493744373 C345.24704688787506 659.1034493744373 342.9911870360379 661.3593092262745 342.9911870360379 664.0936994850636 C342.9911870360379 666.8182993233204 345.24704688787506 669.074199706316 347.97162765264557 669.074199706316 C350.6865267157559 669.074199706316 352.9423279166226 666.8182993233204 352.9423279166226 664.0936994850636 C352.9423279166226 661.3593092262745 350.6865267157559 659.1034493744373 347.97162765264557 659.1034493744373 Z M357.6884273886685 664.9432993233204 C358.15722697973297 664.9432993233204 358.54782718420074 664.5526991188526 358.54782718420074 664.0936994850636 C358.54782718420074 663.6346998512745 358.15722697973297 663.2440996468067 357.6884273886685 663.2440996468067 L355.6474270224576 663.2440996468067 C355.1884273886685 663.2440996468067 354.79782718420074 663.6346998512745 354.79782718420074 664.0936994850636 C354.79782718420074 664.5526991188526 355.1884273886685 664.9432993233204 355.6474270224576 664.9432993233204 L357.6884273886685 664.9432993233204 Z M338.25485724210785 663.2440996468067 C337.79587715864227 663.2440996468067 337.40524917841003 663.6346998512745 337.40524917841003 664.0936994850636 C337.40524917841003 664.5526991188526 337.79587715864227 664.9432993233204 338.25485724210785 664.9432993233204 L340.29587715864227 664.9432993233204 C340.76462739706085 664.9432993233204 341.1552471518521 664.5526991188526 341.1552471518521 664.0936994850636 C341.1552471518521 663.6346998512745 340.76462739706085 663.2440996468067 340.29587715864227 663.2440996468067 L338.25485724210785 663.2440996468067 Z M353.9970268607144 668.9276991188526 C353.67482799291656 668.5955992043018 353.1279262900357 668.5955992043018 352.7958263754849 668.9276991188526 C352.47362750768707 669.2498998939991 352.47362750768707 669.7967996895313 352.7958263754849 670.1288004219532 L354.2705273032193 671.5936994850636 C354.5927280783658 671.91590026021 355.139627873898 671.9061994850636 355.4619278311734 671.5838995277882 C355.79392665624664 671.2518987953663 355.79392665624664 670.7049989998341 355.4619278311734 670.3826990425587 L353.9970268607144 668.9276991188526 Z M340.4814171195035 670.3730001747608 C340.1591572165494 670.6951990425587 340.1591572165494 671.2420988380909 340.4716572165494 671.5741987526417 C340.7939171195035 671.8963995277882 341.3505572676663 671.9061994850636 341.68259710073517 671.5838995277882 L343.1376671195035 670.1288004219532 C343.4697069525723 669.8065996468067 343.4697069525723 669.2596998512745 343.1474370360379 668.9276991188526 C342.8251671195035 668.6053991615772 342.26852697134063 668.6053991615772 341.9364971518521 668.9276991188526 L340.4814171195035 670.3730001747608 Z M348.8310274481778 671.7889986336231 C348.8310274481778 671.3201990425587 348.44042724371 670.9295988380909 347.97162765264557 670.9295988380909 C347.5126270651822 670.9295988380909 347.1220268607144 671.3201990425587 347.1220268607144 671.7889986336231 L347.1220268607144 673.8397989571095 C347.1220268607144 674.2987985908985 347.5126270651822 674.6893987953663 347.97162765264557 674.6893987953663 C348.44042724371 674.6893987953663 348.8310274481778 674.2987985908985 348.8310274481778 673.8397989571095 L348.8310274481778 671.7889986336231 Z "></path>\
                                  	    </defs>\
                                  	    <g style="mix-blend-mode:normal">\
                                  	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-b84bd" fill="#3C3C43" fill-opacity="0.3"></use>\
                                  	    </g>\
                                  	  </g>\
                                  	</svg>\
\
                                  </div>\
                                </div>\
                              </div>\
                            </div>\
                            </div></div></td> \
                              </tr>\
                            </table>\
                            </div>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
              </tbody>\
            </table>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_6" class="richtext autofit firer ie-background commentable non-processed" customid="ON/OFF"   datasizewidth="60.44px" datasizeheight="18.00px" dataX="139.84" dataY="506.50" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_6_0">ON/OFF</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_7" class="richtext manualfit firer ie-background commentable non-processed" customid="Audio Feedback"   datasizewidth="208.94px" datasizeheight="84.00px" dataX="111.00" dataY="665.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_7_0">Audio Feedback</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_9" class="inputIOS checkbox firer commentable non-processed checked" customid="Toggle"  datasizewidth="51.00px" datasizeheight="31.00px" dataX="231.50" dataY="733.50"   value="true"  checked="checked" tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Text_8" class="richtext autofit firer ie-background commentable non-processed" customid="ON/OFF"   datasizewidth="60.44px" datasizeheight="18.00px" dataX="140.00" dataY="740.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_8_0">ON/OFF</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;