jQuery("#simulation")
  .on("drag", ".s-b84bd54c-1480-41ef-8dfb-a8d4bb8142b4 .drag", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    event.data = data;
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Ellipse_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Ellipse_2" ],
                    "top": {
                      "type": "nomove"
                    },
                    "left": {
                      "type": "movewithcursor",
                      "value": ""
                    },
                    "containment": true
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimResize",
                  "parameter": {
                    "target": [ "#s-Rectangle_7" ],
                    "width": {
                      "type": "exprvalue",
                      "value": {
                        "action": "jimMinus",
                        "parameter": [ {
                          "action": "jimMinus",
                          "parameter": [ {
                            "datatype": "property",
                            "target": "#s-Ellipse_2",
                            "property": "jimGetAbsolutePositionX"
                          },{
                            "datatype": "property",
                            "target": "#s-Table_2",
                            "property": "jimGetAbsolutePositionX"
                          } ]
                        },{
                          "action": "jimDivide",
                          "parameter": [ {
                            "datatype": "property",
                            "target": "#s-Ellipse_2",
                            "property": "jimGetWidth"
                          },"2" ]
                        } ]
                      }
                    },
                    "height": {
                      "type": "noresize"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Ellipse_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Ellipse_1" ],
                    "top": {
                      "type": "nomove"
                    },
                    "left": {
                      "type": "movewithcursor",
                      "value": null
                    },
                    "containment": true
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimResize",
                  "parameter": {
                    "target": [ "#s-Rectangle_8" ],
                    "width": {
                      "type": "exprvalue",
                      "value": {
                        "action": "jimMinus",
                        "parameter": [ {
                          "action": "jimMinus",
                          "parameter": [ {
                            "datatype": "property",
                            "target": "#s-Ellipse_1",
                            "property": "jimGetAbsolutePositionX"
                          },{
                            "datatype": "property",
                            "target": "#s-Table_1",
                            "property": "jimGetAbsolutePositionX"
                          } ]
                        },{
                          "action": "jimDivide",
                          "parameter": [ {
                            "datatype": "property",
                            "target": "#s-Ellipse_1",
                            "property": "jimGetWidth"
                          },"2" ]
                        } ]
                      }
                    },
                    "height": {
                      "type": "noresize"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    }
  })
  .on("dragend", ".s-b84bd54c-1480-41ef-8dfb-a8d4bb8142b4 .drag", function(event, data) {
    jimEvent(event).jimRestoreDrag(jQuery(this));
  })
  .on("dragend", ".s-b84bd54c-1480-41ef-8dfb-a8d4bb8142b4 .drag", function(event, data) {
    var id = data.drag.id;
    if(id.startsWith("r")){
    	var numR = id.match(/\d+/)[0];
    	id = id.replace("r"+numR+"_",'');
    }
    if(id.startsWith("s-"))
      jimEvent(event).jimDestroyDrag(jQuery(this));
  });