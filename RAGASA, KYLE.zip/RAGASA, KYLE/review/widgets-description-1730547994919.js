	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Path_1", "bda86572-c923-42e7-8333-b56c3a9c39da"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "bda86572-c923-42e7-8333-b56c3a9c39da"]] = ["Home indicator", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "bda86572-c923-42e7-8333-b56c3a9c39da"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "bda86572-c923-42e7-8333-b56c3a9c39da"]] = ["Battery full", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "bda86572-c923-42e7-8333-b56c3a9c39da"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "bda86572-c923-42e7-8333-b56c3a9c39da"]] = ["Wifi", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "bda86572-c923-42e7-8333-b56c3a9c39da"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "bda86572-c923-42e7-8333-b56c3a9c39da"]] = ["Alarm", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "bda86572-c923-42e7-8333-b56c3a9c39da"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "bda86572-c923-42e7-8333-b56c3a9c39da"]] = ["Date &amp; time", "s-Group_1"]; 

	widgets.descriptionMap[["s-Date_1", "bda86572-c923-42e7-8333-b56c3a9c39da"]] = ""; 

			widgets.rootWidgetMap[["s-Date_1", "bda86572-c923-42e7-8333-b56c3a9c39da"]] = ["Date-Time Input", "s-Date_1"]; 

	widgets.descriptionMap[["s-Date_2", "bda86572-c923-42e7-8333-b56c3a9c39da"]] = ""; 

			widgets.rootWidgetMap[["s-Date_2", "bda86572-c923-42e7-8333-b56c3a9c39da"]] = ["Time input", "s-Date_2"]; 

	widgets.descriptionMap[["s-Input_8", "bda86572-c923-42e7-8333-b56c3a9c39da"]] = ""; 

			widgets.rootWidgetMap[["s-Input_8", "bda86572-c923-42e7-8333-b56c3a9c39da"]] = ["Toggle", "s-Input_8"]; 

	widgets.descriptionMap[["s-Path_1", "dc7c0af5-d918-4cd2-a85c-63dd33111c91"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "dc7c0af5-d918-4cd2-a85c-63dd33111c91"]] = ["Home indicator", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "dc7c0af5-d918-4cd2-a85c-63dd33111c91"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "dc7c0af5-d918-4cd2-a85c-63dd33111c91"]] = ["Battery full", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "dc7c0af5-d918-4cd2-a85c-63dd33111c91"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "dc7c0af5-d918-4cd2-a85c-63dd33111c91"]] = ["Wifi", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "dc7c0af5-d918-4cd2-a85c-63dd33111c91"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "dc7c0af5-d918-4cd2-a85c-63dd33111c91"]] = ["Alarm", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "dc7c0af5-d918-4cd2-a85c-63dd33111c91"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "dc7c0af5-d918-4cd2-a85c-63dd33111c91"]] = ["Date &amp; time", "s-Group_1"]; 

	widgets.descriptionMap[["s-Date_1", "dc7c0af5-d918-4cd2-a85c-63dd33111c91"]] = ""; 

			widgets.rootWidgetMap[["s-Date_1", "dc7c0af5-d918-4cd2-a85c-63dd33111c91"]] = ["Date-Time Input", "s-Date_1"]; 

	widgets.descriptionMap[["s-Date_2", "dc7c0af5-d918-4cd2-a85c-63dd33111c91"]] = ""; 

			widgets.rootWidgetMap[["s-Date_2", "dc7c0af5-d918-4cd2-a85c-63dd33111c91"]] = ["Time input", "s-Date_2"]; 

	widgets.descriptionMap[["s-Path_1", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ["Home indicator", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ["Battery full", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ["Wifi", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ["Alarm", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ["Date &amp; time", "s-Group_1"]; 

	widgets.descriptionMap[["s-Date_1", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ""; 

			widgets.rootWidgetMap[["s-Date_1", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ["Date-Time Input", "s-Date_1"]; 

	widgets.descriptionMap[["s-Date_2", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ""; 

			widgets.rootWidgetMap[["s-Date_2", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ["Time input", "s-Date_2"]; 

	widgets.descriptionMap[["s-Input_8", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ""; 

			widgets.rootWidgetMap[["s-Input_8", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ["Toggle", "s-Input_8"]; 

	widgets.descriptionMap[["s-Input_9", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ""; 

			widgets.rootWidgetMap[["s-Input_9", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ["Toggle", "s-Input_9"]; 

	widgets.descriptionMap[["s-Input_10", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ""; 

			widgets.rootWidgetMap[["s-Input_10", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ["Toggle", "s-Input_10"]; 

	widgets.descriptionMap[["s-Input_11", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ""; 

			widgets.rootWidgetMap[["s-Input_11", "16e1d02e-3e07-4d5e-bce1-8b706fa96727"]] = ["Toggle", "s-Input_11"]; 

	widgets.descriptionMap[["s-Path_1", "2054d39e-2f83-45bb-95fe-e478313758c0"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "2054d39e-2f83-45bb-95fe-e478313758c0"]] = ["Home indicator", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "2054d39e-2f83-45bb-95fe-e478313758c0"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "2054d39e-2f83-45bb-95fe-e478313758c0"]] = ["Battery full", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "2054d39e-2f83-45bb-95fe-e478313758c0"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "2054d39e-2f83-45bb-95fe-e478313758c0"]] = ["Wifi", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "2054d39e-2f83-45bb-95fe-e478313758c0"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "2054d39e-2f83-45bb-95fe-e478313758c0"]] = ["Alarm", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "2054d39e-2f83-45bb-95fe-e478313758c0"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "2054d39e-2f83-45bb-95fe-e478313758c0"]] = ["Date &amp; time", "s-Group_1"]; 

	widgets.descriptionMap[["s-Date_1", "2054d39e-2f83-45bb-95fe-e478313758c0"]] = ""; 

			widgets.rootWidgetMap[["s-Date_1", "2054d39e-2f83-45bb-95fe-e478313758c0"]] = ["Date-Time Input", "s-Date_1"]; 

	widgets.descriptionMap[["s-Date_2", "2054d39e-2f83-45bb-95fe-e478313758c0"]] = ""; 

			widgets.rootWidgetMap[["s-Date_2", "2054d39e-2f83-45bb-95fe-e478313758c0"]] = ["Time input", "s-Date_2"]; 

	widgets.descriptionMap[["s-Path_1", "78d947d0-e83f-4f8d-bebc-50b84c73a38a"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "78d947d0-e83f-4f8d-bebc-50b84c73a38a"]] = ["Home indicator", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "78d947d0-e83f-4f8d-bebc-50b84c73a38a"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "78d947d0-e83f-4f8d-bebc-50b84c73a38a"]] = ["Battery full", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "78d947d0-e83f-4f8d-bebc-50b84c73a38a"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "78d947d0-e83f-4f8d-bebc-50b84c73a38a"]] = ["Wifi", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "78d947d0-e83f-4f8d-bebc-50b84c73a38a"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "78d947d0-e83f-4f8d-bebc-50b84c73a38a"]] = ["Alarm", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "78d947d0-e83f-4f8d-bebc-50b84c73a38a"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "78d947d0-e83f-4f8d-bebc-50b84c73a38a"]] = ["Date &amp; time", "s-Group_1"]; 

	widgets.descriptionMap[["s-Date_1", "78d947d0-e83f-4f8d-bebc-50b84c73a38a"]] = ""; 

			widgets.rootWidgetMap[["s-Date_1", "78d947d0-e83f-4f8d-bebc-50b84c73a38a"]] = ["Date-Time Input", "s-Date_1"]; 

	widgets.descriptionMap[["s-Date_2", "78d947d0-e83f-4f8d-bebc-50b84c73a38a"]] = ""; 

			widgets.rootWidgetMap[["s-Date_2", "78d947d0-e83f-4f8d-bebc-50b84c73a38a"]] = ["Time input", "s-Date_2"]; 

	widgets.descriptionMap[["s-Path_104", "78d947d0-e83f-4f8d-bebc-50b84c73a38a"]] = ""; 

			widgets.rootWidgetMap[["s-Path_104", "78d947d0-e83f-4f8d-bebc-50b84c73a38a"]] = ["Lock open", "s-Path_104"]; 

	widgets.descriptionMap[["s-Path_103", "78d947d0-e83f-4f8d-bebc-50b84c73a38a"]] = ""; 

			widgets.rootWidgetMap[["s-Path_103", "78d947d0-e83f-4f8d-bebc-50b84c73a38a"]] = ["Lock", "s-Path_103"]; 

	widgets.descriptionMap[["s-Path_1", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ["Home indicator", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ["Battery full", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ["Wifi", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ["Alarm", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ["Date &amp; time", "s-Group_1"]; 

	widgets.descriptionMap[["s-Date_1", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ""; 

			widgets.rootWidgetMap[["s-Date_1", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ["Date-Time Input", "s-Date_1"]; 

	widgets.descriptionMap[["s-Date_2", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ""; 

			widgets.rootWidgetMap[["s-Date_2", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ["Time input", "s-Date_2"]; 

	widgets.descriptionMap[["s-Path_6", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ["Plus", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ["Alarm", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_21", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ""; 

			widgets.rootWidgetMap[["s-Path_21", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ["Clock", "s-Path_21"]; 

	widgets.descriptionMap[["s-Path_24", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ""; 

			widgets.rootWidgetMap[["s-Path_24", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ["Stopwatch", "s-Path_24"]; 

	widgets.descriptionMap[["s-Path_25", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ""; 

			widgets.rootWidgetMap[["s-Path_25", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ["Timer", "s-Path_25"]; 

	widgets.descriptionMap[["s-Input_8", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ""; 

			widgets.rootWidgetMap[["s-Input_8", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ["Toggle", "s-Input_8"]; 

	widgets.descriptionMap[["s-Input_9", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ""; 

			widgets.rootWidgetMap[["s-Input_9", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ["Toggle", "s-Input_9"]; 

	widgets.descriptionMap[["s-Input_10", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ""; 

			widgets.rootWidgetMap[["s-Input_10", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ["Toggle", "s-Input_10"]; 

	widgets.descriptionMap[["s-Input_11", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ""; 

			widgets.rootWidgetMap[["s-Input_11", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ["Toggle", "s-Input_11"]; 

	widgets.descriptionMap[["s-Input_12", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ""; 

			widgets.rootWidgetMap[["s-Input_12", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ["Toggle", "s-Input_12"]; 

	widgets.descriptionMap[["s-Input_13", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ""; 

			widgets.rootWidgetMap[["s-Input_13", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ["Toggle", "s-Input_13"]; 

	widgets.descriptionMap[["s-Input_14", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ""; 

			widgets.rootWidgetMap[["s-Input_14", "a9f42a06-ad2b-4292-88a3-c86043c36352"]] = ["Toggle", "s-Input_14"]; 

	widgets.descriptionMap[["s-Path_1", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Home indicator", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Battery full", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Wifi", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alarm", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Date &amp; time", "s-Group_1"]; 

	widgets.descriptionMap[["s-Date_1", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Date_1", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Date-Time Input", "s-Date_1"]; 

	widgets.descriptionMap[["s-Date_2", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Date_2", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Time input", "s-Date_2"]; 

	widgets.descriptionMap[["s-Path_6", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Search", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_7", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Search", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_8", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Search", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_8", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Page control 2", "s-Group_3"]; 

	widgets.descriptionMap[["s-Ellipse_1", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Page control 2", "s-Group_3"]; 

	widgets.descriptionMap[["s-Ellipse_2", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Page control 2", "s-Group_3"]; 

	widgets.descriptionMap[["s-Ellipse_3", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Page control 2", "s-Group_3"]; 

	widgets.descriptionMap[["s-Rectangle_9", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_7"]; 

	widgets.descriptionMap[["s-Paragraph_13", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_7"]; 

	widgets.descriptionMap[["s-Paragraph_14", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_7"]; 

	widgets.descriptionMap[["s-Rectangle_10", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_7"]; 

	widgets.descriptionMap[["s-Paragraph_15", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_7"]; 

	widgets.descriptionMap[["s-Rectangle_11", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_11", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_8"]; 

	widgets.descriptionMap[["s-Paragraph_16", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_8"]; 

	widgets.descriptionMap[["s-Paragraph_17", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_17", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_8"]; 

	widgets.descriptionMap[["s-Rectangle_12", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_8"]; 

	widgets.descriptionMap[["s-Paragraph_18", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_8"]; 

	widgets.descriptionMap[["s-Rectangle_13", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_9"]; 

	widgets.descriptionMap[["s-Paragraph_19", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_19", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_9"]; 

	widgets.descriptionMap[["s-Paragraph_20", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_20", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_9"]; 

	widgets.descriptionMap[["s-Rectangle_14", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_9"]; 

	widgets.descriptionMap[["s-Paragraph_21", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_21", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_9"]; 

	widgets.descriptionMap[["s-Rectangle_1", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_4"]; 

	widgets.descriptionMap[["s-Text_1", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Text_1", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_4"]; 

	widgets.descriptionMap[["s-Text_2", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Text_2", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_4"]; 

	widgets.descriptionMap[["s-Rectangle_2", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_4"]; 

	widgets.descriptionMap[["s-Text_3", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Text_3", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Alert paired actions", "s-Group_4"]; 

	widgets.descriptionMap[["s-Panel_2", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_2", "ac849cdb-956e-4a83-9e45-b234310df425"]] = ["Stacked notification", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Path_1", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Home indicator", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Battery full", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Wifi", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Alarm", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Date &amp; time", "s-Group_1"]; 

	widgets.descriptionMap[["s-Date_1", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Date_1", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Date-Time Input", "s-Date_1"]; 

	widgets.descriptionMap[["s-Date_2", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Date_2", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Time input", "s-Date_2"]; 

	widgets.descriptionMap[["s-Rectangle_6", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Slider", "s-Table_2"]; 

	widgets.descriptionMap[["s-Rectangle_7", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Slider", "s-Table_2"]; 

	widgets.descriptionMap[["s-Ellipse_2", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Slider", "s-Table_2"]; 

	widgets.descriptionMap[["s-Panel_2", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_2", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Slider", "s-Table_2"]; 

	widgets.descriptionMap[["s-Cell_4", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_4", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Slider", "s-Table_2"]; 

	widgets.descriptionMap[["s-Input_8", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Input_8", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Toggle", "s-Input_8"]; 

	widgets.descriptionMap[["s-Rectangle_4", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Slider Icon", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_6", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Slider Icon", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_5", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Slider Icon", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_8", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Slider Icon", "s-Table_1"]; 

	widgets.descriptionMap[["s-Ellipse_1", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Slider Icon", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_1", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Slider Icon", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_9", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Slider Icon", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_7", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Slider Icon", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_3", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_3", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Slider Icon", "s-Table_1"]; 

	widgets.descriptionMap[["s-Input_9", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ""; 

			widgets.rootWidgetMap[["s-Input_9", "b84bd54c-1480-41ef-8dfb-a8d4bb8142b4"]] = ["Toggle", "s-Input_9"]; 

	widgets.descriptionMap[["s-Path_1", "0004e177-187f-48bf-af37-939b7a6cdbc5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "0004e177-187f-48bf-af37-939b7a6cdbc5"]] = ["Home indicator", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "0004e177-187f-48bf-af37-939b7a6cdbc5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "0004e177-187f-48bf-af37-939b7a6cdbc5"]] = ["Battery full", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "0004e177-187f-48bf-af37-939b7a6cdbc5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "0004e177-187f-48bf-af37-939b7a6cdbc5"]] = ["Wifi", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "0004e177-187f-48bf-af37-939b7a6cdbc5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "0004e177-187f-48bf-af37-939b7a6cdbc5"]] = ["Alarm", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "0004e177-187f-48bf-af37-939b7a6cdbc5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "0004e177-187f-48bf-af37-939b7a6cdbc5"]] = ["Date &amp; time", "s-Group_1"]; 

	widgets.descriptionMap[["s-Date_1", "0004e177-187f-48bf-af37-939b7a6cdbc5"]] = ""; 

			widgets.rootWidgetMap[["s-Date_1", "0004e177-187f-48bf-af37-939b7a6cdbc5"]] = ["Date-Time Input", "s-Date_1"]; 

	widgets.descriptionMap[["s-Date_2", "0004e177-187f-48bf-af37-939b7a6cdbc5"]] = ""; 

			widgets.rootWidgetMap[["s-Date_2", "0004e177-187f-48bf-af37-939b7a6cdbc5"]] = ["Time input", "s-Date_2"]; 

	widgets.descriptionMap[["s-Rect_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rect_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Home indicator", "s-Rect_8"]; 

	widgets.descriptionMap[["s-Path_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Battery full", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_30", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_30", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Wifi", "s-Path_30"]; 

	widgets.descriptionMap[["s-Path_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Alarm", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Date &amp; time", "s-List-item-4_11"]; 

	widgets.descriptionMap[["s-Input_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Date-Time Input", "s-Input_8"]; 

	widgets.descriptionMap[["s-Input_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Time input", "s-Input_10"]; 

	widgets.descriptionMap[["s-Input_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Search", "s-Group_3"]; 

	widgets.descriptionMap[["s-Path_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Search", "s-Group_3"]; 

	widgets.descriptionMap[["s-Path_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Search", "s-Group_3"]; 

	widgets.descriptionMap[["s-Path_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Search", "s-Group_3"]; 

	